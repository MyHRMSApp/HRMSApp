/**
* Copyright 2016 IBM Corp.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.sample;

import com.ibm.mfp.security.checks.base.UserAuthenticationSecurityCheck;
import com.ibm.mfp.server.registration.external.model.AuthenticatedUser;

import com.ibm.mfp.adapter.api.OAuthSecurity;
import com.ibm.mfp.server.registration.external.model.ClientData;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;

import java.util.HashMap;
import java.util.Map;
import java.net.*;
import java.io.*;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import org.apache.log4j.Logger;


public class titan_UserLogin extends UserAuthenticationSecurityCheck {

    private String userId, displayName;
    private String errorMsg;
    private static UserManager userManager = new UserManager();
    final static Logger logger = Logger.getLogger(titan_UserLogin.class);

    @Context
	AdapterSecurityContext adapterSecurityContext;

    @Override
    protected AuthenticatedUser createUser() {
        return new AuthenticatedUser(userId, displayName, this.getName());
    }

    /**
     * Get the currently authenticated user
     * @return AuthenticatedUser
     */
    public AuthenticatedUser getUser(){ 
        return authorizationContext.getActiveUser();
    }

    /**
     * Get user is loggedIn
     * @return isLoggedIn
     */
    public boolean isLoggedIn(){
        return this.getState().equals(STATE_SUCCESS);
    }

    /**
     * Get the validate credentials given by Users
     * @return validateCredentials
     */
    @Override
    protected boolean validateCredentials(Map<String, Object> credentials) {
        JSONObject jsonObject = new JSONObject();
        if(credentials!=null && credentials.containsKey("username") && credentials.containsKey("password")){
            String username = credentials.get("username").toString();
            String password = credentials.get("password").toString();
            ClientData clientData = adapterSecurityContext.getClientRegistrationData();
            //Look for this user in the database
            try {
                jsonObject = userManager.getUser(username, password);
                if(jsonObject.getString("EP_RESULT").toString() == "0"){
                    if(clientData.getProtectedAttributes().get("EP_PERNR") != null){
                        clientData.getProtectedAttributes().put("EP_PERNR", jsonObject);
                        adapterSecurityContext.storeClientRegistrationData(clientData);
                        System.out.println("Client data stored Successfully..");
                    }
                    errorMsg = null;
                    return true;
                }else{
                    errorMsg = "Please provide valid Username or Password";
                    System.out.println("Please provide valid Username or Password");
                }
                return false;
            } catch (Exception exception) {
                System.out.println("Exception happend :"+ exception);
                errorMsg = "Please provide valid Username or Password";
                return false;
            }
        }
        else{
            errorMsg = "Please provide valid Username or Password";
            System.out.println("Please provide valid Username or Password");
        }
        return false;
    }

    /**
     * Creating authentication Challenge to throw users 
     * @return createChallenge
     */
    @Override
    protected Map<String, Object> createChallenge() {
        Map challenge = new HashMap();
        challenge.put("errorMsg",errorMsg);
        return challenge;
    }
}
